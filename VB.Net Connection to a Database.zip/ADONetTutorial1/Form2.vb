Imports System.Data.OleDb

Public Class Form2

    Dim ds As New DataSet()
    Dim intCurrentIndex As Integer = 0
    Dim CurrentEmployee As database.EmployeeType
    Dim da As New OleDbDataAdapter()
    Dim conn As New OleDbConnection()


    Private Sub FillForm()
        txtFirstName.Text = CurrentEmployee.FirstName
        txtLastName.Text = CurrentEmployee.LastName
        txtLocation.Text = CurrentEmployee.Location
    End Sub


    Private Sub btnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click
        intCurrentIndex = 0  'Since 0 is the first row
        database.SelectEmployeeRecord(0, CurrentEmployee)
        Call FillForm()
    End Sub


    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        If intCurrentIndex > 0 Then  'We move back only if we're not at the first row.
            intCurrentIndex = intCurrentIndex - 1  'Subtract one from the current index.
            database.SelectEmployeeRecord(intCurrentIndex, CurrentEmployee)
            Call FillForm()
        Else
            MessageBox.Show("You're already at the first record.")
        End If

    End Sub


    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        If intCurrentIndex < database.EmployeeRecordCount() - 1 Then  'We move forward only if we're not at the last row.
            intCurrentIndex = intCurrentIndex + 1  'Subtract one from the current index.
            database.SelectEmployeeRecord(intCurrentIndex, CurrentEmployee)
            Call FillForm()
        Else
            MessageBox.Show("You're already at the last record.")
        End If
    End Sub


    Private Sub btnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
        intCurrentIndex = database.EmployeeRecordCount() - 1 'Count - 1 is the index for the last row
        database.SelectEmployeeRecord(intCurrentIndex, CurrentEmployee)
        Call FillForm()
    End Sub


    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        CurrentEmployee.FirstName = txtFirstName.Text
        CurrentEmployee.LastName = txtLastName.Text
        CurrentEmployee.Location = txtLocation.Text
        database.EmployeeUpdate(CurrentEmployee)
    End Sub


    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        CurrentEmployee.FirstName = txtFirstName.Text
        CurrentEmployee.LastName = txtLastName.Text
        CurrentEmployee.Location = txtLocation.Text
        database.EmployeeAdd(CurrentEmployee)
    End Sub


    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        database.EmployeeDelete()
    End Sub
End Class